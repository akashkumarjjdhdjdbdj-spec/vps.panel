#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
mkdir -p data backups static/uploads/profiles static/uploads/settings static/uploads/os_icons static/img
# Prefer Railway persistent volume when mounted at /data; otherwise use local app data.
if [[ -d /data && -w /data ]]; then
  export DATABASE_PATH="${DATABASE_PATH:-/data/tvm-panel.db}"
else
  export DATABASE_PATH="${DATABASE_PATH:-$PWD/data/tvm-panel.db}"
fi
export HOST="0.0.0.0"
export PORT="${PORT:-5000}"
# Railway manages restarts too; this wrapper only retries short-lived crashes and
# exits after repeated failures to avoid restart loops masking configuration errors.
failures=0
while true; do
  echo "[TVM] Starting panel on ${HOST}:${PORT} (database: ${DATABASE_PATH})"
  python -u Tvm.py && exit 0
  rc=$?
  failures=$((failures + 1))
  echo "[TVM] Process exited with code ${rc}; restart ${failures}/5" >&2
  if (( failures >= 5 )); then
    echo "[TVM] Too many consecutive exits. Check logs/configuration." >&2
    exit "$rc"
  fi
  sleep $((failures * 3))
done
